<?php
// Запрет прямого доступа.
defined('_JEXEC') or die;
?>
