DROP TABLE IF EXISTS `#__vkg_menutree`;
DROP TABLE IF EXISTS `#__vkg_galleries`;
DROP TABLE IF EXISTS `#__vkg_photos`;
