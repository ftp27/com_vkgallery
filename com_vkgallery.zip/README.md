com_vkgallery
=============

Joomla component for gallery with vk.com photos
