<?php
// Запрет прямого доступа.
defined('_JEXEC') or die;
?>
<h2><?php echo $this->item; ?></h2>